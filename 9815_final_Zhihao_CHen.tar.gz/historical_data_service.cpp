#include "historical_data_service.hpp"
#include <fstream>
#include "risk_service.hpp"
#include "streaming_service.hpp"
#include "inquiry_service.hpp"
#include "position_service.hpp"
using namespace std;

void BondHistoricalDataService::PersistData(string persistKey, const Bond & data) {

}

void BondHistoricalDataService::PersistExecutionData(string msg)
{
	exe_connector->Publish(msg);
}

void BondHistoricalDataService::PersistRiskData(PV01<Bond> & pv01)
{
	string msg = "The PV01 is " + std::to_string(pv01.GetPV01());
	risk_connector->Publish(msg);
}
void BondHistoricalDataService::PersistPositionData(Position<Bond> & data)
{
	string msg ="Position of TRSY1:" + to_string(data.GetPosition("TRSY1")) +
		", Position of TRSY2:" + to_string(data.GetPosition("TRSY2")) +
		", Position of TRSY3:" + to_string(data.GetPosition("TRSY3")) +
		", Aggregate Position:" + to_string(data.GetAggregatePosition() );
	position_connector->Publish(msg);
}


void BondHistoricalDataService::PersistStreamingData(PriceStream<Bond> &ps)
{
	cout << "PersistStreamingData.\n";
	string msg;
	double bid = ps.GetBidOrder().GetPrice();
	double offer = ps.GetOfferOrder().GetPrice();
	string cus_id = ps.GetProduct().GetProductId();
	msg = "CUSID: " + cus_id + "; Bid Price: " + std::to_string(bid) +
		"; Offer Price: " + std::to_string(offer);
	streaming_connector->Publish(msg);
}

void BondHistoricalDataService::PersistInquiryData(Inquiry<Bond>& inq)
{
	cout << "Persisting InquiryData\n";
	string msg;
	msg += " Inquiry Id: " + inq.GetInquiryId();
	if (inq.GetSide() == Side::BUY)
		msg += "; BUY ";
	else msg += "; SELL ";
	msg += inq.GetProduct().GetProductId() + " for quantity of ";
	msg += std::to_string(inq.GetQuantity()) + ", at the price of";
	msg += std::to_string(inq.GetPrice());
	inquiry_connector->Publish(msg);
}

BondHistoricalDataService::BondHistoricalDataService() {
	exe_connector = ExecutionDataConnector::get_instance();
	risk_connector = RiskDataConnector::get_instance();
	streaming_connector = StreamingDataConnector::get_instance();
	inquiry_connector = InquiryDataConnector::get_instance();
	position_connector = PositionDataConnector::get_instance();
}


void ExecutionDataConnector::Publish(string & data) {
	ofstream os("data/executions.txt", ios_base::app);
	os << data << endl;
}

void RiskDataConnector::Publish(string & data)
{
	ofstream os("data/risk.txt", ios_base::app);
	os << data << endl;
}

void PositionDataConnector::Publish(string & data)
{
	ofstream os("data/position.txt", ios_base::app);
	os << data << endl;
}


void StreamingDataConnector::Publish(string & data)
{
	ofstream os("data/streaming.txt", ios_base::app);
	os << data << endl;
}

void InquiryDataConnector::Publish(string & data)
{
	ofstream os("data/allinquiries.txt", ios_base::app);
	os << data << endl;
}
