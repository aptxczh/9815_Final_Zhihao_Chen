#include "execution_service.hpp"
#include "historical_data_service.hpp"
// Execute an order on a market
void BondExecutionService::ExecuteOrder(const ExecutionOrder<Bond>& order, Market market) {
	cout << "executing order in ExecutionService\n";
	for (auto listener : _listeners)
		listener->ProcessAdd(const_cast<ExecutionOrder<Bond>& >(order));
}

BondExecutionService::BondExecutionService() {
	AddListener(ExecutionServiceListener::get_instance());
}

void ExecutionServiceListener::ProcessAdd(ExecutionOrder<Bond> &data)
{
	string cus_id = data.GetProduct().GetProductId();
	string msg = "Executing Order... OrderId: " + data.GetOrderId()
		+ ", CUSID: " + cus_id;
	service->PersistExecutionData(msg);
}

