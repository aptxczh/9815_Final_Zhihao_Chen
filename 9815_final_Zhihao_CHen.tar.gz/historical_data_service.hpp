/**
 * historicaldataservice.hpp
 * historicaldataservice.hpp
 *
 * @author Breman Thuraisingham
 * Defines the data types and Service for historical data.
 *
 * @author Breman Thuraisingham
 */
#ifndef HISTORICAL_DATA_SERVICE_HPP
#define HISTORICAL_DATA_SERVICE_HPP
#include "common_header.h"


class BondHistoricalDataService;
class ExecutionDataConnector;
class RiskDataConnector;
class StreamingDataConnector;
class InquiryDataConnector;
class PositionDataConnector;
template <class T>
class PV01;
template <class T>
class PriceStream;
template <class T>
class Inquiry;
template <class T>
class Position;

 /**
  * Service for processing and persisting historical data to a persistent store.
  * Keyed on some persistent key.
  * Type T is the data type to persist.
  */

template<typename T>
class HistoricalDataService : public Service<string, T>
{

public:

	// Persist data to a store
	virtual void PersistData(string persistKey, const T& data) = 0;
};


//TODO: Split BondHistoricalDataService into 5 parts
class BondHistoricalDataService : public HistoricalDataService<Bond>
{
public:
	static BondHistoricalDataService* get_instance() {
		static BondHistoricalDataService instance;
		return &instance;
	}

	// Persist data to a store
	Bond& GetData(string key) { return data[key]; }
	void OnMessage(Bond &trade) {}
	void AddListener(ServiceListener<Bond> *listener) { _listeners.push_back(listener); }
	virtual const vector< ServiceListener<Bond>* >& GetListeners() const { return _listeners; }
	// Execute an order on a market
	void PersistData(string persistKey, const Bond& data);
	void PersistExecutionData(string msg);
	void PersistRiskData(PV01<Bond> & pv01);
	void PersistStreamingData(PriceStream<Bond> &ps);
	void PersistInquiryData(Inquiry<Bond>& msg);
	void PersistPositionData(Position<Bond>& msg);
private:
	BondHistoricalDataService();
	ExecutionDataConnector *exe_connector;
	RiskDataConnector *risk_connector; 
	StreamingDataConnector *streaming_connector;
	InquiryDataConnector *inquiry_connector;
	PositionDataConnector *position_connector;
	vector<ServiceListener<Bond>*> _listeners;
};
//TODO: Split BondHistoricalDataService into 5 parts
class ExecutionDataConnector : Connector<string>
{
public:
	static ExecutionDataConnector *get_instance() {
		static ExecutionDataConnector instance;
		return &instance;
	}
	virtual void Publish(string &data);
private:
	ExecutionDataConnector() {}
};

class RiskDataConnector : Connector<string>
{
public:
	static RiskDataConnector *get_instance() {
		static RiskDataConnector instance;
		return &instance;
	}
	virtual void Publish(string &data);
private:
	RiskDataConnector() {}
};


class StreamingDataConnector : Connector<string>
{
public:
	static StreamingDataConnector *get_instance() {
		static StreamingDataConnector instance;
		return &instance;
	}
	virtual void Publish(string &data);
private:
	StreamingDataConnector() {}
};


class InquiryDataConnector : Connector<string>
{
public:
	static InquiryDataConnector *get_instance() {
		static InquiryDataConnector instance;
		return &instance;
	}
	virtual void Publish(string &data);
private:
	InquiryDataConnector() {}
};
class PositionDataConnector : Connector<string>
{
public:
	static PositionDataConnector *get_instance() {
		static PositionDataConnector instance;
		return &instance;
	}
	virtual void Publish(string &data);
private:
	PositionDataConnector() {}
};

#endif
