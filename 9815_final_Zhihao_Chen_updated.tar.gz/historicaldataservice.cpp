#include "historicaldataservice.hpp"
#include <fstream>
#include "riskservice.hpp"
#include "streamingservice.hpp"
#include "inquiryservice.hpp"
#include "positionservice.hpp"
using namespace std;

void BondHistoricalDataService::PersistData(string persistKey, const Bond & data) {
//Do nothing
}

void BondHistoricalDataService::PersistExecutionData(string msg)
{//Publish Execution hisotry data to connector
	exe_connector->Publish(msg);
}

void BondHistoricalDataService::PersistRiskData(PV01<Bond> & pv01)
{//Publish risk history data to connector
	string msg = "The PV01 is " + std::to_string(pv01.GetPV01());
	risk_connector->Publish(msg);
}
void BondHistoricalDataService::PersistPositionData(Position<Bond> & data)
{//publish position history data to connector
	string msg ="Position of TRSY1:" + to_string(data.GetPosition("TRSY1")) +
		", Position of TRSY2:" + to_string(data.GetPosition("TRSY2")) +
		", Position of TRSY3:" + to_string(data.GetPosition("TRSY3")) +
		", Aggregate Position:" + to_string(data.GetAggregatePosition() );
	position_connector->Publish(msg);
}


void BondHistoricalDataService::PersistStreamingData(PriceStream<Bond> &ps)
{//publish streaming history data to connector
	cout << "PersistStreamingData.\n";
	string msg;
	double bid = ps.GetBidOrder().GetPrice();
	double offer = ps.GetOfferOrder().GetPrice();
	string cus_id = ps.GetProduct().GetProductId();
	msg = "CUSID: " + cus_id + "; Bid Price: " + std::to_string(bid) +
		"; Offer Price: " + std::to_string(offer);
	streaming_connector->Publish(msg);
}

void BondHistoricalDataService::PersistInquiryData(Inquiry<Bond>& inq)
{//publish inquiry hisotry data to connector
	cout << "Persisting InquiryData\n";
	string msg;
	msg += " Inquiry Id: " + inq.GetInquiryId();
	if (inq.GetSide() == Side::BUY)
		msg += "; BUY ";
	else msg += "; SELL ";
	msg += inq.GetProduct().GetProductId() + " for quantity of ";
	msg += std::to_string(inq.GetQuantity()) + ", at the price of";
	msg += std::to_string(inq.GetPrice());
	inquiry_connector->Publish(msg);
}

BondHistoricalDataService::BondHistoricalDataService() {//add connector when the service is initialized
	exe_connector = ExecutionDataConnector::get_instance();
	risk_connector = RiskDataConnector::get_instance();
	streaming_connector = StreamingDataConnector::get_instance();
	inquiry_connector = InquiryDataConnector::get_instance();
	position_connector = PositionDataConnector::get_instance();
}


void ExecutionDataConnector::Publish(string & data) { // publish to file
	ofstream os("data/executions.txt", ios_base::app);
	os << data << endl;
}

void RiskDataConnector::Publish(string & data)
{//publish to file
	ofstream os("data/risk.txt", ios_base::app);
	os << data << endl;
}

void PositionDataConnector::Publish(string & data)
{//publish to file
	ofstream os("data/position.txt", ios_base::app);
	os << data << endl;
}


void StreamingDataConnector::Publish(string & data)
{//publish to file
	ofstream os("data/streaming.txt", ios_base::app);
	os << data << endl;
}

void InquiryDataConnector::Publish(string & data)
{// publish to file
	ofstream os("data/allinquiries.txt", ios_base::app);
	os << data << endl;
}
