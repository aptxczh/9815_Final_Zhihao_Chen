#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <random>
#include "tradebookingservice.hpp"
#include "pricingservice.hpp"
#include "commonheader.h"
#include "products.hpp"
#include "marketdataservice.hpp"
#include "inquiryservice.hpp"

using namespace std;
void generate_data(){
	generate_prices_data();
    generate_trade_data();
	generate_market_data();
    generate_inquiries_data();
}
int main(){
    //Test
	//generate_data();
	initialize_global_values();
    //Get data from 4 sources
	InquiryConnector::get_instance()->GetInquiries();
	PricingServiceConnector::get_instance()->GetPriceData();
	BondTradeBookingConnector::get_instance()->GetTradingData();
	MarketDataConnector::get_instance()->GetMarketData();
    return 0;
}
