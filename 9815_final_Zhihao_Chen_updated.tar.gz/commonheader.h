/**
 * Created by Zhihao Chen, on 2016-12-17
 * Include necessary declarations.
 */
#ifndef _COMMON_HEADER_H_
#define _COMMON_HEADER_H_
#include <vector>
#include <iostream>
#include <string>
#include <map>
#include "soa.hpp"
using namespace std;
//Base Service Class
template<typename K, typename V>
class Service;

// Derived Service Classes
class BondTradeBookingService;
class BondTradeServiceListener;
class BondTradeBookingConnector;
class BondPositionService;
class BondPositionServiceListener;
class BondPositionService;
class BondRiskService;
class HistoricalDataServiceListener;
class BondHistoricalDataService;
class BondAlgoExecutionService;
class BondAlgoExecutionServiceListener;
class BondExecutionService;
template<typename T>
class OrderBook;
template<typename T>
class Trade;
template<typename T>
class Position;
enum Side { BUY, SELL };
enum PricingSide { BID, OFFER };
class Bond;
void generate_trade_data();
void generate_prices_data();
void generate_market_data();
void generate_inquiries_data();
// when reading csv, split one line with ',' then return a vector of strings
vector<string> line_split(string &line);

// transform price like to double
double str_to_price(string str);

// transform the generated random number into a  string
string rand_to_string(int num);

// global variables; Use CUSIP to access and update bonds and positions
extern map<string, Bond> bonds;
extern map<string, Position<Bond>  > all_positions;
void initialize_global_values();
#endif

