#include "executionservice.hpp"
#include "historicaldataservice.hpp"
// Execute an order on a market
string toString(Market market);
void BondExecutionService::ExecuteOrder(const ExecutionOrder<Bond>& order, Market market) {//pass data from service to listener
    cout << "executing order on market: "<<toString(market)<<"\n";
	for (auto listener : _listeners)
		listener->ProcessAdd(const_cast<ExecutionOrder<Bond>& >(order));
}

BondExecutionService::BondExecutionService() {
	AddListener(ExecutionServiceListener::get_instance());
}

void ExecutionServiceListener::ProcessAdd(ExecutionOrder<Bond> &data)
{//pass data from listener to next service: historicaldataservice
	string cus_id = data.GetProduct().GetProductId();
	string msg = "Executing Order... OrderId: " + data.GetOrderId()
		+ ", CUSID: " + cus_id;
	service->PersistExecutionData(msg);
}

string toString(Market market) { //help function for printing out market information
  	if (market == Market::BROKERTEC)
  		return "BROKERTEC";
  	if (market == Market::CME)
  		return "CME";
  	else
  		return "ESPEED";
  }
