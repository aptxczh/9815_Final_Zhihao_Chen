#include "streamingservice.hpp"
#include "historicaldataservice.hpp"


PriceStreamOrder::PriceStreamOrder(double _price, long _visibleQuantity, long _hiddenQuantity, PricingSide _side)
{//initialize PriceStreamOrder
	price = _price;
	visibleQuantity = _visibleQuantity;
	hiddenQuantity = _hiddenQuantity;
	side = _side;
}

double PriceStreamOrder::GetPrice() const
{
	return price;
}

long PriceStreamOrder::GetVisibleQuantity() const
{
	return visibleQuantity;
}

long PriceStreamOrder::GetHiddenQuantity() const
{
	return hiddenQuantity;
}
void StreamServiceListener::ProcessAdd(PriceStream<Bond> &data)
{//Call Next Service's method : persist data
	service->PersistStreamingData(data);
}


